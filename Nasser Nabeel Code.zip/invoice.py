from booking import Booking

class Invoice:
    """
    Invoice class - Handles billing information for a booking
    """

    def __init__(self, booking: Booking, nightly_rate: float, additional_charges: float, discounts: float):
        self.__invoice_id = f"INV-{booking.get_booking_id()}"
        self.__booking = booking
        self.__nightly_rate = nightly_rate
        self.__additional_charges = additional_charges
        self.__discounts = discounts
        self.__total_amount = 0.0

    # Getter methods
    def get_invoice_id(self) -> str:
        return self.__invoice_id

    def get_total_amount(self) -> float:
        return self.__total_amount

    # Functional methods
    def calculate_total(self) -> float:
        self.__total_amount = (self.__nightly_rate + self.__additional_charges) - self.__discounts
        return self.__total_amount

    def display_invoice(self) -> None:
        print(f"Invoice ID: {self.__invoice_id}")
        print(f"Booking ID: {self.__booking.get_booking_id()}")
        print(f"Nightly Rate: AED {self.__nightly_rate}")
        print(f"Additional Charges: AED {self.__additional_charges}")
        print(f"Discounts: AED {self.__discounts}")
        print(f"Total Amount: AED {self.__total_amount}")

    def __str__(self) -> str:
        return f"Invoice {self.__invoice_id} - Total: AED {self.__total_amount}"
