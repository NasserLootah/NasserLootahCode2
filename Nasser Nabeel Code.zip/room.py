class Room:
    """
    Room class - Represents a hotel room
    """

    def __init__(self, room_number: int, room_type: str, amenities: list, price_per_night: float, availability_status: bool = True):
        self.__room_number = room_number
        self.__room_type = room_type
        self.__amenities = amenities
        self.__price_per_night = price_per_night
        self.__availability_status = availability_status

    # Getter methods
    def get_room_number(self) -> int:
        return self.__room_number

    def get_room_type(self) -> str:
        return self.__room_type

    def get_amenities(self) -> list:
        return self.__amenities

    def get_price_per_night(self) -> float:
        return self.__price_per_night

    def is_available(self) -> bool:
        return self.__availability_status

    # Setter methods
    def update_status(self, status: bool) -> None:
        self.__availability_status = status

    # Functional method
    def get_room_details(self) -> str:
        return f"Room {self.__room_number}: {self.__room_type}, Amenities: {', '.join(self.__amenities)}, Price: {self.__price_per_night}, Available: {self.__availability_status}"

    def check_availability(self) -> bool:
        return self.__availability_status

    def __str__(self) -> str:
        return f"Room {self.__room_number} ({self.__room_type}) - AED {self.__price_per_night} - Available: {self.__availability_status}"
