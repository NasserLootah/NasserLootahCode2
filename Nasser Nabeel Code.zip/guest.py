from human import Human

class Guest(Human):
    """
    Guest class - Inherits from Human and adds guest-specific attributes
    """

    def __init__(self, guest_id: int, name: str, email: str, contact: str, loyalty_points: int = 0):
        super().__init__(name, email, contact)
        self.__guest_id = guest_id
        self.__loyalty_points = loyalty_points
        self.__reservation_history = []  # List to store past bookings

    # Getter Methods
    def get_guest_id(self) -> int:
        return self.__guest_id

    def get_loyalty_points(self) -> int:
        return self.__loyalty_points

    def get_reservation_history(self) -> list:
        return self.__reservation_history

    # Setter Methods
    def set_loyalty_points(self, points: int):
        self.__loyalty_points = points

    # Functional Methods
    def add_loyalty_points(self, points: int):
        self.__loyalty_points += points

    def redeem_points(self, points: int):
        if points <= self.__loyalty_points:
            self.__loyalty_points -= points
        else:
            print("Not enough loyalty points to redeem.")

    def add_reservation(self, booking):
        self.__reservation_history.append(booking)

    def view_reservation_history(self):
        if not self.__reservation_history:
            print("No reservations found.")
        else:
            for res in self.__reservation_history:
                print(res)

    def update_profile(self, name: str, email: str, contact: str):
        self.set_name(name)
        self.set_email(email)
        self.set_contact(contact)

    def __str__(self) -> str:
        return f"{super().__str__()}, Guest ID: {self.__guest_id}, Loyalty Points: {self.__loyalty_points}"
