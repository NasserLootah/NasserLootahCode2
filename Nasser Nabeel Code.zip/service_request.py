from guest import Guest

class ServiceRequest:
    """
    ServiceRequest class - Handles additional services requested by guests
    """

    def __init__(self, request_id: int, guest: Guest, service_type: str, status: str = "Pending"):
        self.__request_id = request_id
        self.__guest = guest
        self.__service_type = service_type
        self.__status = status

    # Getter methods
    def get_request_id(self) -> int:
        return self.__request_id

    def get_status(self) -> str:
        return self.__status

    # Functional methods
    def create_request(self) -> None:
        print(f"Service request '{self.__service_type}' created for Guest ID {self.__guest.get_guest_id()}.")

    def update_status(self, status: str) -> None:
        self.__status = status
        print(f"Service request {self.__request_id} status updated to {status}.")

    def __str__(self) -> str:
        return f"Request ID: {self.__request_id}, Guest: {self.__guest.get_guest_id()}, Service: {self.__service_type}, Status: {self.__status}"
