from room import Room
from guest import Guest

class Booking:
    """
    Booking class - Manages room bookings
    """

    def __init__(self, booking_id: int, guest: Guest, room: Room, check_in_date: str, check_out_date: str, status: str = "Confirmed"):
        self.__booking_id = booking_id
        self.__guest = guest
        self.__room = room
        self.__check_in_date = check_in_date
        self.__check_out_date = check_out_date
        self.__status = status
        self.__invoice = None 

    # Getter methods
    def get_booking_id(self) -> int:
        return self.__booking_id

    def get_guest(self) -> Guest:
        return self.__guest

    def get_room(self) -> Room:
        return self.__room

    def get_status(self) -> str:
        return self.__status

    # Functional methods
    def create_booking(self) -> None:
        if self.__room.is_available():
            self.__room.update_status(False)
            print(f"Booking {self.__booking_id} created for Guest {self.__guest.get_guest_id()}")
        else:
            print("Room not available!")

    def cancel_booking(self) -> None:
        if self.__status != "Cancelled":
            self.__status = "Cancelled"
            self.__room.update_status(True)
            print(f"Booking {self.__booking_id} has been cancelled.")
        else:
            print("Booking already cancelled.")

    def generate_invoice(self) -> "Invoice":
        from invoice import Invoice
        self.__invoice = Invoice(self, self.__room.get_price_per_night(), 0.0, 0.0)
        print(f"Invoice generated for Booking {self.__booking_id}")
        return self.__invoice

    def send_confirmation(self) -> None:
        print(f"Confirmation sent for Booking {self.__booking_id} to Guest {self.__guest.get_guest_id()}")

    def __str__(self) -> str:
        return f"Booking ID: {self.__booking_id}, Guest: {self.__guest.get_guest_id()}, Room: {self.__room.get_room_number()}, Status: {self.__status}"
