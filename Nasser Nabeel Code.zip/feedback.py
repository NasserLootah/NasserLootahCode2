from guest import Guest

class Feedback:
    """
    Feedback class - Handles guest feedback and ratings
    """

    def __init__(self, feedback_id: int, guest: Guest, rating: int, comments: str):
        self.__feedback_id = feedback_id
        self.__guest = guest
        self.__rating = rating
        self.__comments = comments

    # Functional methods
    def submit_feedback(self) -> None:
        print(f"Feedback submitted by Guest {self.__guest.get_guest_id()} with rating {self.__rating}/5.")

    def view_feedback(self) -> str:
        return f"Rating: {self.__rating}/5, Comments: {self.__comments}"

    def __str__(self) -> str:
        return f"Feedback ID: {self.__feedback_id}, Guest: {self.__guest.get_guest_id()}, Rating: {self.__rating}, Comments: {self.__comments}"
