from invoice import Invoice

class Payment:
    """
    Payment class - Processes payment for an invoice
    """

    def __init__(self, payment_id: int, invoice: Invoice, payment_method: str):
        self.__payment_id = payment_id
        self.__invoice = invoice
        self.__payment_method = payment_method
        self.__payment_status = "Pending"

    # Getter methods
    def get_payment_id(self) -> int:
        return self.__payment_id

    def get_payment_status(self) -> str:
        return self.__payment_status

    # Functional methods
    def process_payment(self) -> None:
        total = self.__invoice.calculate_total()
        if total > 0:
            self.__payment_status = "Completed"
            print(f"Payment of AED {total} completed using {self.__payment_method}.")
        else:
            print("Invalid total amount. Payment failed.")

    def payment_details(self) -> str:
        return f"Payment ID: {self.__payment_id}, Method: {self.__payment_method}, Status: {self.__payment_status}"

    def __str__(self) -> str:
        return f"Payment {self.__payment_id} - Status: {self.__payment_status}"
