# Import required classes
from guest import Guest
from room import Room
from booking import Booking
from invoice import Invoice
from payment import Payment
from service_request import ServiceRequest
from feedback import Feedback

# ------------------------------
# Class: Tester
# Handles all hotel system operations
# ------------------------------
class Tester:
    def __init__(self):
        # Lists to store all objects
        self.guests = []
        self.rooms = []
        self.bookings = []
        self.service_requests = []
        self.feedbacks = []
        self.payments = []

        # Add dummy UAE-based Guests
        guest1 = Guest(1, "Ahmed Al Mansoori", "ahmed.mansoori@gmail.com", "+971501234567", 100)
        guest2 = Guest(2, "Fatima Al Nuaimi", "fatima.nuaimi@yahoo.com", "+971552223344", 250)
        self.guests.append(guest1)
        self.guests.append(guest2)

        # Add dummy Rooms
        room1 = Room(1001, "Single", ["WiFi", "TV", "Mini-bar"], 350.0)
        room2 = Room(1002, "Double", ["WiFi", "TV", "Mini-bar", "Balcony"], 550.0)
        room3 = Room(2001, "Suite", ["WiFi", "TV", "Mini-bar", "Sea View", "Jacuzzi"], 950.0)
        self.rooms.append(room1)
        self.rooms.append(room2)
        self.rooms.append(room3)

        print("\n--- Dummy Data Loaded ---")

    # Create a new Guest Account
    def create_guest(self):
        try:
            guest_id = int(input("Enter Guest ID: "))
            name = input("Enter Name: ")
            email = input("Enter Email: ")
            contact = input("Enter Contact: ")
            points = int(input("Enter Loyalty Points: "))
            guest = Guest(guest_id, name, email, contact, points)
            self.guests.append(guest)
            print("Guest account created successfully.")
            print(guest)
        except Exception as e:
            print("Error:", e)

    # Add a new room
    def add_room(self):
        try:
            room_no = int(input("Enter Room Number: "))
            room_type = input("Enter Room Type: ")
            amenities = input("Enter Amenities (comma separated): ").split(",")
            price = float(input("Enter Price per Night: "))
            room = Room(room_no, room_type, amenities, price)
            self.rooms.append(room)
            print("Room added successfully.")
            print(room)
        except Exception as e:
            print("Error:", e)

    # Display all available rooms
    def search_rooms(self):
        print("\nAvailable Rooms:")
        for r in self.rooms:
            if r.is_available():
                print(r)

    # Make a room reservation
    def make_reservation(self):
        try:
            booking_id = int(input("Enter Booking ID: "))
            guest_id = int(input("Enter Guest ID: "))

            # Search for Guest
            guest = None
            for g in self.guests:
                if g.get_guest_id() == guest_id:
                    guest = g
            if not guest:
                print("Guest not found!")
                return

            # Search for Room
            room_no = int(input("Enter Room Number: "))
            room = None
            for r in self.rooms:
                if r.get_room_number() == room_no:
                    room = r
            if not room:
                print("Room not found!")
                return
            if not room.is_available():
                print("Room not available!")
                return

            # Create booking
            check_in = input("Enter Check-in Date: ")
            check_out = input("Enter Check-out Date: ")
            booking = Booking(booking_id, guest, room, check_in, check_out)
            booking.create_booking()
            self.bookings.append(booking)
            guest.add_reservation(booking)
            print("Booking created successfully.")
            print(booking)
        except Exception as e:
            print("Error:", e)

    # Cancel an existing reservation
    def cancel_reservation(self):
        try:
            booking_id = int(input("Enter Booking ID to cancel: "))
            booking = None
            for b in self.bookings:
                if b.get_booking_id() == booking_id:
                    booking = b
            if not booking:
                print("Booking not found!")
                return
            booking.cancel_booking()
        except Exception as e:
            print("Error:", e)

    # Generate invoice for a booking
    def generate_invoice(self):
        try:
            booking_id = int(input("Enter Booking ID to generate invoice: "))
            booking = None
            for b in self.bookings:
                if b.get_booking_id() == booking_id:
                    booking = b
            if not booking:
                print("Booking not found!")
                return
            invoice = booking.generate_invoice()
            invoice.calculate_total()
            invoice.display_invoice()
        except Exception as e:
            print("Error:", e)

    # Process payment for an invoice
    def process_payment(self):
        try:
            booking_id = int(input("Enter Booking ID to process payment: "))
            booking = None
            for b in self.bookings:
                if b.get_booking_id() == booking_id:
                    booking = b
            if not booking:
                print("Booking not found!")
                return
            if not booking._Booking__invoice:
                print("No invoice found. Generate invoice first.")
                return
            payment_id = int(input("Enter Payment ID: "))
            method = input("Enter Payment Method (Card/Wallet): ")
            payment = Payment(payment_id, booking._Booking__invoice, method)
            payment.process_payment()
            self.payments.append(payment)
        except Exception as e:
            print("Error:", e)

    # Make a service request
    def make_service_request(self):
        try:
            request_id = int(input("Enter Request ID: "))
            guest_id = int(input("Enter Guest ID: "))
            guest = None
            for g in self.guests:
                if g.get_guest_id() == guest_id:
                    guest = g
            if not guest:
                print("Guest not found!")
                return
            service_type = input("Enter Service Type: ")
            request = ServiceRequest(request_id, guest, service_type)
            request.create_request()
            self.service_requests.append(request)
        except Exception as e:
            print("Error:", e)

    # Submit guest feedback
    def submit_feedback(self):
        try:
            feedback_id = int(input("Enter Feedback ID: "))
            guest_id = int(input("Enter Guest ID: "))
            guest = None
            for g in self.guests:
                if g.get_guest_id() == guest_id:
                    guest = g
            if not guest:
                print("Guest not found!")
                return
            rating = int(input("Enter Rating (1-5): "))
            comments = input("Enter Comments: ")
            fb = Feedback(feedback_id, guest, rating, comments)
            fb.submit_feedback()
            self.feedbacks.append(fb)
        except Exception as e:
            print("Error:", e)

    # View all past bookings of a guest
    def view_reservation_history(self):
        try:
            guest_id = int(input("Enter Guest ID: "))
            guest = None
            for g in self.guests:
                if g.get_guest_id() == guest_id:
                    guest = g
            if not guest:
                print("Guest not found!")
                return
            print(f"Reservation history for Guest {guest_id}:")
            guest.view_reservation_history()
        except Exception as e:
            print("Error:", e)


# ------------------------------
# Class: MainMenu
# Displays options and links to Tester functions
# ------------------------------
class MainMenu:
    def __init__(self):
        self.tester = Tester()

    # Display the main menu
    def display_menu(self):
        while True:
            print("\n--- Royal Stay Hotel Management System ---")
            print("1. Create Guest Account")
            print("2. Add Room")
            print("3. Search Available Rooms")
            print("4. Make Room Reservation")
            print("5. Cancel Reservation")
            print("6. Generate Invoice")
            print("7. Process Payment")
            print("8. Make Service Request")
            print("9. Submit Feedback")
            print("10. View Reservation History")
            print("11. Exit")

            try:
                choice = int(input("Enter your choice: "))
            except ValueError:
                print("Invalid input! Please enter a number.")
                continue

            # Menu options
            if choice == 1:
                self.tester.create_guest()
            elif choice == 2:
                self.tester.add_room()
            elif choice == 3:
                self.tester.search_rooms()
            elif choice == 4:
                self.tester.make_reservation()
            elif choice == 5:
                self.tester.cancel_reservation()
            elif choice == 6:
                self.tester.generate_invoice()
            elif choice == 7:
                self.tester.process_payment()
            elif choice == 8:
                self.tester.make_service_request()
            elif choice == 9:
                self.tester.submit_feedback()
            elif choice == 10:
                self.tester.view_reservation_history()
            elif choice == 11:
                print("Thank you for using Royal Stay Hotel System!")
                break
            else:
                print("Invalid choice. Please try again.")


# ------------------------------
# Program Starting Point
# ------------------------------
if __name__ == "__main__":
    menu = MainMenu()
    menu.display_menu()
