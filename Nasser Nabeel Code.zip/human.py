class Human:
    """
    Human class - Base class for common human attributes
    """

    def __init__(self, name: str, email: str, contact: str):
        self.__name = name
        self.__email = email
        self.__contact = contact

    # Getter Methods
    def get_name(self) -> str:
        return self.__name

    def get_email(self) -> str:
        return self.__email

    def get_contact(self) -> str:
        return self.__contact

    # Setter Methods
    def set_name(self, name: str):
        self.__name = name

    def set_email(self, email: str):
        self.__email = email

    def set_contact(self, contact: str):
        self.__contact = contact

    def __str__(self) -> str:
        return f"Name: {self.__name}, Email: {self.__email}, Contact: {self.__contact}"
